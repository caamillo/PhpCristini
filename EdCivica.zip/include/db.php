<?php
// Basic connection settings
$databaseHost = 'localhost';
$databaseUsername = 'caamillo';
$databasePassword = 'caamillo';
$databaseName = 'scuola';

// Connect to the database
$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 
?>